<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_pelanggan');
        $this->load->model('m_auth');
        
    }
    
    public function register()
    {
        
        $this->form_validation->set_rules('nama_pelanggan', 'Nama Pelanggan', 'required', array(
            'required' => '%s Mohon diisi !!'
        ));

        $this->form_validation->set_rules('email', 'Konfirmasi Email', 'required|is_unique[tbl_costumer.email]', array(
            'required' => '%s Mohon diisi !!',
            'is_unique' => '%s <br> Email ini sudah digunakan !!'
        ));
        
        $this->form_validation->set_rules('password', 'Password', 'required', array(
            'required' => '%s Mohon diisi !!'
        ));

        $this->form_validation->set_rules('ulangi_password', 'Konfirmasi Password', 'required|matches[password]', array(
            'required' => '%s Mohon diisi !!',
            'matches' => '%s <br> Password yang dimasukkan tidak cocok !!'
        ));

        $this->form_validation->set_rules('alamat', 'Alamat Rumah', 'required', array(
            'required' => '%s Mohon diisi !!'
        ));

        $this->form_validation->set_rules('no_telepon', 'Konfirmasi No Telepon', 'required|is_unique[tbl_costumer.no_telepon]', array(
            'required' => '%s Mohon diisi !!',
            'is_unique' => '%s <br> No Telepon ini sudah digunakan !!'
        ));

        if ($this->form_validation->run() == FALSE) {
            $data = array(
                'title' => 'Pendaftaran Pelanggan',
                'isi' => 'v_register'
         );
         $this->load->view('layout/v_wrapper_frontend', $data, FALSE);

        } else {
            $data = array(
                'nama_pelanggan' => $this->input->post('nama_pelanggan'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'alamat' => $this->input->post('alamat'),
                'no_telepon' => $this->input->post('no_telepon'),
            );
            $this->m_pelanggan->register($data);
            $this->session->set_flashdata('pesan', 'Pendaftaran akun berhasil !!');
            redirect('pelanggan/register');
        }
    }

    public function login()
    {
        $this->form_validation->set_rules('email', 'Email', 'required', array(
            'required' => '%s Mohon Diisi !!' 
        ));

        $this->form_validation->set_rules('password', 'Password', 'required', array(
            'required' => '%s Mohon Diisi !!' 
        ));
        
        if ($this->form_validation->run() == TRUE) {
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $this->pelanggan_login->login($email, $password);
        }    

        $data = array(
            'title' => 'Login Pelanggan',
            'isi' => 'v_login_pelanggan'
     );
     $this->load->view('layout/v_wrapper_frontend', $data, FALSE); 
    }

    public function logout()
    {
        $this->pelanggan_login->logout();
    }

    public function akun()
    {
        $this->pelanggan_login->proteksi_halaman();
        $data = array(
            'title' => 'Akun Pelanggan',
            'isi' => 'v_akun_saya'
     );
     $this->load->view('layout/v_wrapper_frontend', $data, FALSE); 
    }

}