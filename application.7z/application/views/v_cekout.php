  <!-- Main content -->
  <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-shopping-cart"></i> Check Out 
                    <small class="float-right">Tanggal: <?= date('d-m-Y') ?></small>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                    <div class="col-12 table-responsive">
                      <table class="table table-striped">
                      <thead>
                      <tr>
                      <th class="text-center">Quantity</th>
                      <th class="text-center">Harga</th>
                      <th class="text-center">Barang</th>
                      <th class="text-center">Total Harga</th>
                      <th class="text-center">Berat</th>
                    </tr>
                    </thead>
                    <tbody>
            <?php 
            $i = 1;
            $total_berat = 0;
            foreach ($this->cart->contents() as $items) { 
                    $barang = $this->m_home->detail_barang($items['id']);
                    $berat = $items['qty'] * $barang->berat;
                    $total_berat =  $total_berat + $berat;
                ?>
                    <tr>
                        <td class="text-center"> <?php echo $items['qty']; ?> </td>
                        <td class="text-center"> Rp. <?php echo number_format($items['price'], 0); ?></td>
                        <td class="text-center"> <?php echo $items['name']; ?> </td>
                        <td class="text-center"> Rp. <?php echo number_format($items['subtotal'] ,0); ?></td>
                        <td class="text-center"> <?= $berat ?> Gr </td>
                    </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
              <?php
               echo validation_errors('<div class="alert alert-danger alert-dismissible">
               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>', ' </div>');
              ?>
              <?php 
              echo form_open('belanja/cekout');
              $no_order = date('Ymd') . strtoupper(random_string('alnum', 8));
              ?>
              <div class="row">
                <!-- accepted payments column -->
                <div class="col-sm-8 invoice-col">
                  Tujuan :
                  <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                        <label> Provinsi </label>
                        <select name="provinsi" class="form-control"></select>
                       </div>
                          </div>

                          <div class="col-sm-6">
                          <div class="form-group">
                          <label>  Kabupaten </label>
                            <select name="kota" class="form-control"> </select>
                                  </div>
                                </div>

                          <div class="col-sm-6">
                          <div class="form-group">
                          <label> Kecamatan </label>
                            <input name="kecamatan" class="form-control" placeholder="Cikarang Selatan" required>
                                  </div>
                                </div>

                          <div class="col-sm-6">
                          <div class="form-group">
                          <label> No. Telepon </label>
                            <input name="no_telepon" class="form-control" placeholder="No Telepon Penerima" required>
                                  </div>
                                </div>

                            
                          <div class="col-sm-6">
                          <div class="form-group">
                          <label> Nama Penerima </label>
                            <input name="nama_penerima" class="form-control" required>
                                  </div>
                                </div>

                          <div class="col-sm-6">
                          <div class="form-group">
                          <label> Alamat </label>
                            <input name="alamat" class="form-control" placeholder="---Jalan--Blok--No.Rumah---" required>
                                  </div>
                                </div>

                   </div>
                </div>
                <!-- /.col -->
                <div class="col-4">
    
                  <div class="table-responsive">
                    <table class="table">
                    <br>
                    <br>
                    <br>
                    <br>
                      <tr>
                        <th style="width:50%">Grand Total :</th>
                        <td><label> <?php echo number_format($this->cart->total() ,0); ?> </label></td>
                      </tr>
                      <tr>
                        <th>Berat :</th>
                        <td><label> <?= $total_berat ?> Gr </label> </td>
                      </tr>
                      <tr>
                        <th>Total Bayar :</th>
                        <td><label>Rp. <?php echo number_format($this->cart->total() ,0); ?> </label></td>
                      </tr>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Simpan Transaksi -->
              <input name="no_order" value="<?= $no_order ?>" hidden>
              <input name="berat" value="<?= $total_berat ?>" hidden> <br>
              <input name="grand_total" value="<?= $this->cart->total() ?>" hidden>
              <input name="total_bayar" value="<?= $this->cart->total() ?>" hidden>
               <!-- End Simpan Transaksi -->

               <!-- Simpan Rincian Transaksi -->
                <?php 
                $i = 1;
                foreach ($this->cart->contents() as $items) {
                  echo form_hidden('qty' . $i++, $items['qty']);
                }
                ?>
                <!-- End Simpan Rincian Transaksi -->

              <div class="row no-print">
                <div class="col-12">
                  <a href="<?= base_url('belanja') ?>" class="btn btn-danger"><i class="fas fa-backward"></i> Kembali Ke Keranjang</a>
            
                  <button type="submit" class="btn btn-primary float-right" style="margin-right: 5px;">
                    <i class="fas fa-shopping-cart"></i> Proses Check Out
                  </button>
                </div>
              </div>
              <?php echo form_close() ?>
            </div>
            
  <script>
    $(document).ready(function() {
        //masukkan data ke provinsi
        $.ajax({
            type: "POST",
            url: "<?= base_url('rajaongkir/provinsi') ?>",
            success: function(hasil_provinsi) {
                //console.log(hasil_provinsi);
                $("select[name=provinsi]").html(hasil_provinsi);
            }
        });

        //masukkan data ke kota
        $("select[name=provinsi]").on("change", function() {
            var id_provinsi_terpilih = $("option:selected", this).attr("id_provinsi");
            $.ajax({
            type: "POST",
            url: "<?= base_url('rajaongkir/kota') ?>",
            data : 'id_provinsi=' + id_provinsi_terpilih,
            success: function(hasil_kota) {
                //console.log(hasil_provinsi);
                $("select[name=kota]").html(hasil_kota);
                }
            });
        });

        $("select[name=kota]").on("change", function() {           
            $.ajax({
            type: "POST",
            url: "<?= base_url('rajaongkir/expedisi') ?>",
            success: function(hasil_expedisi) {
                $("select[name=expedisi]").html(hasil_expedisi);
                }
            });
        });

        $("select[name=expedisi]").on("change", function() {           
            $.ajax({
            type: "POST",
            url: "<?= base_url('rajaongkir/paket') ?>",
            success: function(hasil_paket) {
                $("select[name=paket]").html(hasil_paket);
                }
            });
        });

    });
</script>