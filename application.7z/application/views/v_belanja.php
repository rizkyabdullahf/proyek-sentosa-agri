<div class="card card-solid">
    <div class="card-body pb-0">
        <div class="row">
        <div class="col-sm-12">
        <?php
        if($this->session->flashdata('pesan')) {
            echo '<div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-check"></i>';
            echo $this->session->flashdata('pesan');
            echo '</h5></div>';
        }
        ?>
        </div>
        <div class="col-sm-12">
        <?php echo form_open('belanja/update'); ?>

            <table class="table" cellpadding="6" cellspacing="1" style="width:100%">
            <thead class="text-center">
            <tr>
                    <th class="text-center" width="100px"> Quantity </th>
                    <th class="text-center"> Nama Barang </th>
                    <th class="text-center"> Harga </th>
                    <th class="text-center"> Sub-Total</th>
                    <th class="text-center"> Berat </th>
                    <th class="text-center"> Action </th>
            </tr>
            </thead>
            <tbody>
            <?php $i = 1; ?>

            <?php 
             $total_berat = 0;
            foreach ($this->cart->contents() as $items) { 
                    $barang = $this->m_home->detail_barang($items['id']);
                    $berat = $items['qty'] * $barang->berat;
                    $total_berat =  $total_berat + $berat;
                ?>
            <tr>
                <td class="text-center"> <?php 
                echo form_input(array(
                'name' => $i.'[qty]', 
                'value' => $items['qty'], 
                'maxlength' => '3', 
                'min' => '0',
                'size' => '5', 
                'type' => 'number', 
                'class' => 'form-control'
            )); ?>
                </td>
                <td class="text-center"> <?php echo $items['name']; ?> </td>
                <td class="text-center"> Rp. <?php echo number_format($items['price'], 0); ?></td>
                <td class="text-center"> Rp. <?php echo number_format($items['subtotal'] ,0); ?></td>
                <td class="text-center"> <?= $berat ?> Gr </td>
                <td class="text-center">  
                    <a href="<?= base_url('belanja/delete/' .$items['rowid']) ?>" class="btn btn-danger 
                    btn-sm"> <i class="fa fa-trash"> </i> </a> </td>
                </tr>

            <?php $i++; ?>

            <?php } ?>

    <tr>
        <td class="right"><h4> Total :</h4></td>
        <td class="right"> <h4> Rp. <?php echo number_format($this->cart->total() ,0); ?> </h4> </td>
        <th> Total Berat : <?= $total_berat ?> Gram </th>
        <td> </td>
        <td> </td>
        <td> </td>
    </tr>
        </tbody>
            </table>
            
            <button type="submit" class="btn btn-primary btn-flat"> <i class="fa fa-save"> Perbaharui Belanja </i> </button>
            <a href="<?= base_url('belanja/clear') ?>" class="btn btn-danger btn-flat"> <i class="fa fa-recycle"> Kosongkan Belanja </i> </a>
                <a href="<?= base_url('belanja/cekout') ?>" class="btn btn-success btn-flat"> <i class="fa fa-check-square"> Buat Pesanan Belanja </i> </a>
                 
                <?php echo form_close(); ?>
            <br>
                </div>
            </div>
        </div>
    </div>